﻿using System;
using System.Collections.Generic;

namespace Parcial_1_Alisson_Murillo
{
    internal class Program
    {
        static List<Cliente> clientes = new List<Cliente>();

        static void Main(string[] args)
        {
            int op = 0;

            Console.WriteLine("Bienvenido al sistema de gestión de clientes.");

            while (op != 6)
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1. Agregar Cliente");
                Console.WriteLine("2. Mostrar Clientes");
                Console.WriteLine("3. Consultar Cliente");
                Console.WriteLine("4. Editar Cliente");
                Console.WriteLine("5. Eliminar Cliente");
                Console.WriteLine("6. Salir");
                Console.WriteLine("Ingrese una opción: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        AgregarCliente();
                        break;
                    case 2:
                        MostrarClientes();
                        break;
                    case 3:
                        ConsultarCliente();
                        break;
                    case 4:
                        EditarCliente();
                        break;
                    case 5:
                        EliminarCliente();
                        break;
                    case 6:
                        Console.WriteLine("Saliendo ...........");
                        return;
                    default:
                        Console.WriteLine("Opción incorrecta, ingrese opción entre 1 y 6.");
                        break;
                }
            }
        }

        static void AgregarCliente()
        {
            Console.WriteLine("Ingrese el nombre del cliente:");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese la dirección del cliente:");
            string direccion = Console.ReadLine();

            Console.WriteLine("Ingrese el teléfono del cliente:");
            string telefono = Console.ReadLine();

            Console.WriteLine("Ingrese el correo electrónico del cliente:");
            string correoElectronico = Console.ReadLine();

            Cliente nuevoCliente = new Cliente(nombre, direccion, telefono, correoElectronico);
            clientes.Add(nuevoCliente);

            Console.WriteLine("Cliente agregado correctamente.");
        }

        static void MostrarClientes()
        {
            if (clientes.Count == 0)
            {
                Console.WriteLine("No hay clientes registrados.");
                return;
            }

            Console.WriteLine("Lista de Clientes:");
            foreach (Cliente cliente in clientes)
            {
                cliente.MostrarInformacion();
                Console.WriteLine("--------------------");
            }

        }
        static void ConsultarCliente()
        {
            Console.WriteLine("Ingrese el nombre del cliente a consultar:");
            string NombreConsultar = Console.ReadLine();

            Cliente clienteConsultar = clientes.Find(c => c.Nombre == NombreConsultar);
            if (clienteConsultar != null)
            {
                clienteConsultar.MostrarInformacion();
            }
            else
            {
                Console.WriteLine("Cliente no encontrado.");
            }
        }
        static void EditarCliente()
        {
            Console.WriteLine("Ingrese el nombre del cliente a editar:");
            string NombreEditar = Console.ReadLine();

            Cliente clienteEditar = clientes.Find(c => c.Nombre == NombreEditar);
            if (clienteEditar != null)
            {
                Console.WriteLine("Ingrese el nuevo nombre del cliente:");
                string NuevoNombre = Console.ReadLine();

                Console.WriteLine("Ingrese la nueva dirección del cliente:");
                string NuevaDireccion = Console.ReadLine();

                Console.WriteLine("Ingrese el nuevo teléfono del cliente:");
                string NuevoTelefono = Console.ReadLine();

                Console.WriteLine("Ingrese el nuevo correo electrónico del cliente:");
                string NuevoCorreoElectronico = Console.ReadLine();

                clienteEditar.Nombre = NuevoNombre;
                clienteEditar.Direccion = NuevaDireccion;
                clienteEditar.Telefono = NuevoTelefono;
                clienteEditar.CorreoElectronico = NuevoCorreoElectronico;

                Console.WriteLine("Cliente actualizado correctamente.");
            }
            else
            {
                Console.WriteLine("Cliente no encontrado.");
            }
        }
        static void EliminarCliente()
        {
            Console.WriteLine("Ingrese el nombre del cliente a eliminar:");
            string NombreEliminar = Console.ReadLine();

            Cliente clienteEliminar = clientes.Find(c => c.Nombre == NombreEliminar);
            if (clienteEliminar != null)
            {
                clientes.Remove(clienteEliminar);
                Console.WriteLine("Cliente eliminado correctamente.");
            }
            else
            {
                Console.WriteLine("Cliente no encontrado.");
            }
        }
    }
}
