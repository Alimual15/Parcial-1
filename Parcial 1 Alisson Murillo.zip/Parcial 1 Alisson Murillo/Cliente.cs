﻿using System;

namespace Parcial_1_Alisson_Murillo
{
    internal class Cliente
    {
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string CorreoElectronico { get; set; }

        public Cliente(string nombre, string direccion, string telefono, string correoElectronico)
        {
            Nombre = nombre;
            Direccion = direccion;
            Telefono = telefono;
            CorreoElectronico = correoElectronico;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Dirección: " + Direccion);
            Console.WriteLine("Teléfono: " + Telefono);
            Console.WriteLine("Correo electrónico: " + CorreoElectronico);
        }
    }
}
